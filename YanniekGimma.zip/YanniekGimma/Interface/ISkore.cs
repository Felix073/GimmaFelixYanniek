﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YanniekGimma.Interface
{
    public interface ISkore
    {
        string Name { get; set; }
        int Points { get; set; }
    }
}
